-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2021 at 07:20 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `feedback` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `feedback`) VALUES
('Abhijit Biswas', 'abhijitbiswas1999@gmail.com', 'Very Nice'),
('Abhijit Biswas', 'abhijitbiswas1999@gmail.com', 'Bohot Accha site banaya hay bhisahab'),
('Sruthy', 'sruthy.k2019@vitstudent.ac.in', 'It is Very Good');

-- --------------------------------------------------------

--
-- Table structure for table `loginform`
--

CREATE TABLE `loginform` (
  `id` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loginform`
--

INSERT INTO `loginform` (`id`, `email`, `password`) VALUES
('abhijit', 'abhijit.biswas2019@vitstudent.ac.in', 'abhijit'),
('admin', 'abhijitbiswas1999@gmail.com', 'admin'),
('avinash', 'avi5050@gmail.com', 'avinash'),
('sruthy', 'sruthy.k2019@vitstudent.ac.in', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `newreg`
--

CREATE TABLE `newreg` (
  `id` varchar(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mob` varchar(10) DEFAULT NULL,
  `address` varchar(70) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `proof` varchar(15) DEFAULT NULL,
  `prf1` varchar(15) DEFAULT NULL,
  `checkin` date DEFAULT NULL,
  `checkout` date DEFAULT NULL,
  `room` int(5) DEFAULT NULL,
  `rtype` varchar(10) DEFAULT NULL,
  `adult` int(5) DEFAULT NULL,
  `children` int(5) DEFAULT NULL,
  `rend` float(8,3) DEFAULT NULL,
  `rm1` varchar(14) DEFAULT NULL,
  `timest` time DEFAULT NULL,
  `regid` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newreg`
--

INSERT INTO `newreg` (`id`, `name`, `email`, `mob`, `address`, `country`, `proof`, `prf1`, `checkin`, `checkout`, `room`, `rtype`, `adult`, `children`, `rend`, `rm1`, `timest`, `regid`) VALUES
('abhijit', 'Abhijit Biswas', 'abhijit.biswas2019@vitstudent.', '8436348794', 'Vandalur-Kelambakkam Road', 'india', 'aadhaar', '2123 4567 8972', '2020-08-07', '2020-08-27', 1, 'Double', 1, 0, 2999.000, '201 ', '04:45:02', 44389),
('sruthy', 'Sruthy K', 'sruthy.k2019@vitstudent.ac.in', '8436348794', 'Kharida Bidhanpally, Kharagpur, Paschim Midnapur', 'india', 'aadhaar', '2123 4567 8975', '2020-08-06', '2020-08-15', 1, 'Suite', 1, 0, 2999.000, '301 ', '06:13:00', 51999);

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `mailid` varchar(50) DEFAULT NULL,
  `roomno` int(3) DEFAULT NULL,
  `query` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`mailid`, `roomno`, `query`) VALUES
('abhijit.biswas2019@vitstudent.ac.in', 201, 'Fan Problem'),
('abhijit.biswas2019@vitstudent.ac.in', 201, 'Fan Problem'),
('abhijit.biswas2019@vitstudent.ac.in', 201, 'Fan'),
('abhijit.biswas2019@vitstudent.ac.in', 201, 'Bathroom is so dirty');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `roomno` int(3) NOT NULL,
  `roomtype` varchar(20) DEFAULT NULL,
  `roomstatus` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`roomno`, `roomtype`, `roomstatus`) VALUES
(101, 'Single', 'Free'),
(102, 'Single', 'Free'),
(103, 'Single', 'Free'),
(104, 'Single', 'Free'),
(105, 'Single', 'Free'),
(201, 'Double', 'Reserved'),
(202, 'Double', 'Free'),
(203, 'Double', 'Free'),
(204, 'Double', 'Free'),
(205, 'Double', 'Free'),
(301, 'Suite', 'Reserved'),
(302, 'Suite', 'Free'),
(303, 'Suite', 'Free'),
(304, 'Suite', 'Free'),
(305, 'Suite', 'Free');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `loginform`
--
ALTER TABLE `loginform`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newreg`
--
ALTER TABLE `newreg`
  ADD KEY `id` (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`roomno`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `newreg`
--
ALTER TABLE `newreg`
  ADD CONSTRAINT `newreg_ibfk_1` FOREIGN KEY (`id`) REFERENCES `loginform` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
